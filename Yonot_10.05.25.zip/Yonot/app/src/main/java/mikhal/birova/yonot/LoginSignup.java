package mikhal.birova.yonot;

import android.app.DatePickerDialog;
import android.content.ContentValues;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.speech.tts.TextToSpeech;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.FrameLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.fragment.app.FragmentTransaction;

import java.util.Calendar;
import java.util.concurrent.Executor;
import java.util.concurrent.Executors;

public class LoginSignup extends AppCompatActivity {

    LoginFragment loginFragment;
    SignUpFragment signUpFragment;
    TextView tvWhat;
    Context context;
    FrameLayout fragment_container;
    int count=0;
    Button bContinue, bGuest;
    String stName="",stPassword="", stPhone="", stEmail="", stBD="";
    HelperDB helperDB;
    SQLiteDatabase db;
    User user;
    int cyear, cmonth, cday;
    public static int isTTS=1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login_signup);

        initComponents();

        bGuest.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                User user1=new User("","","","","");
                AlertDialog.Builder adb=new AlertDialog.Builder(context);
                adb.setTitle("You really to be a guest?");
                adb.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        Intent go=new Intent(context, Guide.class);
                        go.putExtra("user",user1);
                        startActivity(go);
                    }
                });
                adb.setNegativeButton("One moment", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                    }
                });
                adb.create().show();
            }
        });

        tvWhat.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                count++;
                if (count%2==1) {
                    tvWhat.setText("I have an account");
                    signUpFragment = new SignUpFragment();
                    FragmentTransaction ft = getSupportFragmentManager().beginTransaction();
                    ft.replace(R.id.fragment_container, signUpFragment);
                    ft.commit();
                }
                else {
                    tvWhat.setText("I don't have a account");
                    loginFragment=new LoginFragment();
                    FragmentTransaction ft=getSupportFragmentManager().beginTransaction();
                    ft.replace(R.id.fragment_container, loginFragment);
                    ft.commit();
                }
            }
        });

        bContinue.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (count%2==1)  {
                    signUpFragment.etNameSU.setOnFocusChangeListener(new View.OnFocusChangeListener() {
                        @Override
                        public void onFocusChange(View v, boolean hasFocus) {
                            if (hasFocus)
                                signUpFragment.etNameSU.setBackgroundColor(Color.WHITE);
                        }
                    });
                    signUpFragment.etPasswordSU.setOnFocusChangeListener(new View.OnFocusChangeListener() {
                        @Override
                        public void onFocusChange(View v, boolean hasFocus) {
                            if (hasFocus)
                                signUpFragment.etPasswordSU.setBackgroundColor(Color.WHITE);
                        }
                    });
                    signUpFragment.etPhoneSU.setOnFocusChangeListener(new View.OnFocusChangeListener() {
                        @Override
                        public void onFocusChange(View v, boolean hasFocus) {
                            if (hasFocus)
                                signUpFragment.etPhoneSU.setBackgroundColor(Color.WHITE);
                        }
                    });
                    signUpFragment.etEmailSU.setOnFocusChangeListener(new View.OnFocusChangeListener() {
                        @Override
                        public void onFocusChange(View v, boolean hasFocus) {
                            if (hasFocus)
                                signUpFragment.etEmailSU.setBackgroundColor(Color.WHITE);
                        }
                    });

                    stName=signUpFragment.etNameSU.getText().toString();
                    stPassword=signUpFragment.etPasswordSU.getText().toString();
                    stPhone=signUpFragment.etPhoneSU.getText().toString();
                    stEmail=signUpFragment.etEmailSU.getText().toString();

                    if (stName.equals(""))  {
                        signUpFragment.etNameSU.setBackgroundColor(Color.RED);
                        My_Toast.showToast(context,"User's name not found!",11 );
                        if (isTTS==1)
                            TTSManager.getInstance().speak("User's name not found!",
                                    TextToSpeech.QUEUE_FLUSH,null,null);

                        return;
                    }
                    if (stPassword.equals(""))  {
                        signUpFragment.etNameSU.setBackgroundColor(Color.RED);
                        My_Toast.showToast(context,"Password not found!",1);
                        if (isTTS==1)
                            TTSManager.getInstance().speak("Password not found!",
                                TextToSpeech.QUEUE_FLUSH,null,null);
                        return;
                    }
                    if (stPhone.equals(""))  {
                        signUpFragment.etNameSU.setBackgroundColor(Color.RED);
                        My_Toast.showToast(context,"Phone's number not found!",1);
                        if (isTTS==1)
                            TTSManager.getInstance().speak("Phone's number not found!",
                                    TextToSpeech.QUEUE_FLUSH,null,null);
                        return;
                    }
                    if (stEmail.equals(""))  {
                        signUpFragment.etNameSU.setBackgroundColor(Color.RED);
                        My_Toast.showToast(context,"E-mail not found!",1);
                        if (isTTS==1)
                            TTSManager.getInstance().speak("E-mail not found!",
                                    TextToSpeech.QUEUE_FLUSH,null,null);
                        return;
                    }
                    String emailPattern = "^[a-zA-Z0-9]+[a-zA-Z0-9._-]{1,}(?<!\\.)@[a-zA-Z0-9]{2,}\\.[a-zA-Z]{2,}$|" +
                            "^[a-zA-Z0-9]{2,}\\.([a-zA-Z0-9]{2,})@[a-zA-Z0-9]{2,}\\.[a-zA-Z]{2,}$";
                    if (!stEmail.matches(emailPattern)) {
                        signUpFragment.etNameSU.setBackgroundColor(Color.RED);
                        My_Toast.showToast(context,"E-mail not standart!",1);
                        if (isTTS==1)
                            TTSManager.getInstance().speak("E-mail not standart!",
                                    TextToSpeech.QUEUE_FLUSH,null,null);
                        return;
                    }
                    if (isUserFound(stName, stPassword))  {
                        My_Toast.showToast(context,"Insert other data",1);
                        if (isTTS==1)
                            TTSManager.getInstance().speak("Insert other data",
                                    TextToSpeech.QUEUE_FLUSH,null,null);
                        return;
                    }
                    //saveUserDataToDatabase(user);
                    goNext(user);
                }
                else   {
                    loginFragment.etNameLF.setOnFocusChangeListener(new View.OnFocusChangeListener() {
                        @Override
                        public void onFocusChange(View v, boolean hasFocus) {
                            if (hasFocus)
                                loginFragment.etNameLF.setBackgroundColor(Color.WHITE);
                        }
                    });
                    loginFragment.etPasswordLF.setOnFocusChangeListener(new View.OnFocusChangeListener() {
                        @Override
                        public void onFocusChange(View v, boolean hasFocus) {
                            if (hasFocus)
                                loginFragment.etPasswordLF.setBackgroundColor(Color.WHITE);
                        }
                    });
                    stName=loginFragment.etNameLF.getText().toString();
                    if (stName.equals(""))  {
                        loginFragment.etNameLF.setBackgroundColor(Color.RED);
                        My_Toast.showToast(context,"User's name not found!",1);
                        if (isTTS==1)
                            TTSManager.getInstance().speak("User's name not found!",
                                    TextToSpeech.QUEUE_FLUSH,null,null);
                        return;
                    }
                    stPassword=loginFragment.etPasswordLF.getText().toString();
                    if (stPassword.equals(""))  {
                        loginFragment.etPasswordLF.setBackgroundColor(Color.RED);
                        My_Toast.showToast(context,"Password not found!",1);
                        if (isTTS==1)
                            TTSManager.getInstance().speak("Password not found!",
                                    TextToSpeech.QUEUE_FLUSH,null,null);
                        return;
                    }
                    if (isUserFound(stName, stPassword))  {
                        //goNext(user);
                        Intent intent = new Intent(context, Home.class);
                        intent.putExtra("user",user);
                        context.startActivity(intent);
                    }
                    else {
                        My_Toast.showToast(context,"User not found",11);
                        if (isTTS==1)
                            TTSManager.getInstance().speak("User not found",
                                    TextToSpeech.QUEUE_FLUSH,null,null);
                    }
                }
            }
        });
    }

    public void setLoginData(User SUuser) {
        user=SUuser;
        stName=user.getuName();
        stPassword=user.getuPass();
        stPhone=user.getuPhone();
        stEmail=user.getuMail();
        stBD=user.getuBD();
        initComponents();
    }

    private void goNext(User user) {
        AlertDialog.Builder builder = new AlertDialog.Builder(context);
        LayoutInflater inflater = LayoutInflater.from(context);
        View dialogView = inflater.inflate(R.layout.sign_up_dialog, null);
        builder.setView(dialogView);

        TextView tvUserData = dialogView.findViewById(R.id.tvUserData);
        Button bCancel = dialogView.findViewById(R.id.bCancel);
        Button bNext = dialogView.findViewById(R.id.bNext);

        String userData = "Name: " + user.getuName() + "\n" +
                "Password: " + user.getuPass() + "\n" +
                "Email: " + user.getuMail() + "\n" +
                "Phone: " + user.getuPhone() + "\n" +
                "Birthday: " + user.getuBD();
        tvUserData.setText(userData);

        AlertDialog alertDialog = builder.create();

        bCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                alertDialog.dismiss();
            }
        });

        bNext.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                saveUserDataToDatabase(user);
                /*Intent intent = new Intent(context, Home.class);
                intent.putExtra("user",user);
                context.startActivity(intent);*/
                alertDialog.dismiss();
            }
        });
        alertDialog.show();
    }

    private void saveUserDataToDatabase(User user) {
        Executor executor = Executors.newSingleThreadExecutor();
        Handler handler = new Handler(Looper.getMainLooper());

        executor.execute(() -> {
            SQLiteDatabase db = null;
            try {
                db = helperDB.getWritableDatabase();
                ContentValues contentValues = new ContentValues();
                contentValues.put(helperDB.USER_NICKNAME, user.getuName());
                contentValues.put(helperDB.USER_PASSWORD, user.getuPass());
                contentValues.put(helperDB.USER_EMAIL, user.getuMail());
                contentValues.put(helperDB.USER_PHONE, user.getuPhone());
                contentValues.put(helperDB.USER_BD, user.getuBD());
                long result = db.insert(helperDB.USERS_TABLE, null, contentValues);
                handler.post(() -> {
                    if (result == -1) {
                        My_Toast.showToast(context,"Error writing data to DB",11);
                        if (isTTS==1)
                            TTSManager.getInstance().speak("Error writing data to DB",TextToSpeech.QUEUE_FLUSH,null,null);
                    } else {
                        My_Toast.showToast(context,"Data saved in success",12);
                        if (isTTS==1)
                            TTSManager.getInstance().speak("Data saved in success",TextToSpeech.QUEUE_FLUSH,null,null);
                        Intent intent = new Intent(context, Home.class);
                        intent.putExtra("user", user);
                        context.startActivity(intent);
                    }
                });
            } catch (Exception e) {
                handler.post(() -> My_Toast.showToast(context,"Error!",11));
            } finally {
                if (db != null) {
                    db.close();
                }
            }
        });
    }

    private boolean isUserFound(String stName, String stPassword) {
        boolean flag=false;
        db=helperDB.getReadableDatabase();
        Cursor cursor=db.query(helperDB.USERS_TABLE,
                null,null,null,
                null,null,null);
        if (cursor.getCount()==0) {
            db.close();
            return flag;
        }
        cursor.moveToFirst();
        while (flag==false && !cursor.isAfterLast())  {
            String pointerName=cursor.getString((int)cursor.getColumnIndex(helperDB.USER_NICKNAME));
            String pointerPassword=cursor.getString((int)cursor.getColumnIndex(helperDB.USER_PASSWORD));
            if (pointerName.equals(stName) || pointerPassword.equals(stPassword))  {
                String pointerPhone=cursor.getString((int)cursor.getColumnIndex(helperDB.USER_PHONE));
                String pointerMail=cursor.getString((int)cursor.getColumnIndex(helperDB.USER_EMAIL));
                String pointerBD=cursor.getString((int)cursor.getColumnIndex(helperDB.USER_BD));
                user=new User(pointerName,pointerPassword,pointerPhone,pointerMail, pointerBD);
                flag=true;
            }
            cursor.moveToNext();
        }
        db.close();
        return flag;
    }


    private void initComponents() {
        context=this;
        helperDB=new HelperDB(context);
        tvWhat=findViewById(R.id.tvWhat);
        bContinue=findViewById(R.id.bContinue);
        bGuest=findViewById(R.id.bGuest);

        Calendar calendar = Calendar.getInstance();
        cyear = calendar.get(Calendar.YEAR);
        cmonth = calendar.get(Calendar.MONTH);
        cday = calendar.get(Calendar.DAY_OF_MONTH);

        fragment_container=findViewById(R.id.fragment_container);
        loginFragment=new LoginFragment();
        FragmentTransaction ft=getSupportFragmentManager().beginTransaction();
        ft.replace(R.id.fragment_container, loginFragment);
        ft.commit();
        tvWhat.setText("I don't have a account");
        if (isTTS==1)
            TTSManager.getInstance().speak("Welcome to pegion's application",
                TextToSpeech.QUEUE_FLUSH,null,null);
    }
}