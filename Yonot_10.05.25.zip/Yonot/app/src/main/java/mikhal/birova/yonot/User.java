package mikhal.birova.yonot;

import java.io.Serializable;

public class User implements Serializable {
    private String uName;
    private String uPass;
    private String uMail;
    private String uPhone;
    private String uBD;

    public User(String uName, String uPass, String uMail, String uPhone, String uBD) {
        this.uName = uName;
        this.uPass = uPass;
        this.uMail = uMail;
        this.uPhone = uPhone;
        this.uBD = uBD;
    }

    public String getuName() {
        return uName;
    }

    public void setuName(String uName) {
        this.uName = uName;
    }

    public String getuPass() {
        return uPass;
    }

    public void setuPass(String uPass) {
        this.uPass = uPass;
    }

    public String getuMail() {
        return uMail;
    }

    public void setuMail(String uMail) {
        this.uMail = uMail;
    }

    public String getuPhone() {
        return uPhone;
    }

    public void setuPhone(String uPhone) {
        this.uPhone = uPhone;
    }

    public String getuBD() {
        return uBD;
    }

    public void setuBD(String uBD) {
        this.uBD = uBD;
    }

    @Override
    public String toString() {
        return "User{" +
                "uName='" + uName + '\'' +
                ", uPass='" + uPass + '\'' +
                ", uMail='" + uMail + '\'' +
                ", uPhone='" + uPhone + '\'' +
                ", uBD='" + uBD + '\'' +
                '}';
    }
}
