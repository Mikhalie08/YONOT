package mikhal.birova.yonot;

import android.content.Intent;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;


public class SecondHandFragment extends Fragment {

    private LinearLayout LLSH;
    String[][] forButtons={{},{},{}};
    int[] picsID={R.drawable.add_pegion};
    private ImageView ivMenuSHF;
    private BaseMenu baseMenu;
    private Button bChat,b1,b2,b3,bb1,bb2,bb3;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view= inflater.inflate(R.layout.fragment_second_hand, container, false);

        b1=view.findViewById(R.id.bPigeon);
        b2=view.findViewById(R.id.bEquip);
        b3=view.findViewById(R.id.bService);
        bb1=view.findViewById(R.id.bP1);
        bb1=view.findViewById(R.id.bP2);
        bb1=view.findViewById(R.id.bP3);
        bb1=view.findViewById(R.id.bE1);
        bb1=view.findViewById(R.id.bE2);
        bb1=view.findViewById(R.id.bE3);
        bb1=view.findViewById(R.id.bS1);
        bb1=view.findViewById(R.id.bS2);

        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                bb1.setText(forButtons[0][0]);
                bb1.setCompoundDrawablesWithIntrinsicBounds(R.drawable.add_pegion, 0, 0, 0);
            }
        });

        bChat=view.findViewById(R.id.bChat);
        bChat.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent go=new Intent(getContext(), ChatFirebaseActivity.class);
                startActivity(go);
                }
        });
        ivMenuSHF=view.findViewById(R.id.ivMenuSHF);
        baseMenu=new BaseMenu(getContext());
        ivMenuSHF.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                baseMenu.showPopupMenu(v);
            }
        });

        return view;
    }
}