package mikhal.birova.yonot;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class HelperDB extends SQLiteOpenHelper {

    public static final String DB_FILE="yonot.db";
    //=========================
    public static final String USERS_TABLE="Users";
    public static final String USER_NICKNAME="userName";
    public static final String USER_PASSWORD="userPass";
    public static final String USER_EMAIL="userEmail";
    public static final String USER_PHONE="userPhone";
    public static final String USER_BD="userBD";
    //=========================
    public static final String PIGEON_TABLE="Pigeon";
    public static final String PIGEON_CHIP_ID="pChip";
    public static final String PIGEON_NAME="pName";
    public static final String PIGEON_SPECIES="pSpecies";
    public static final String PIGEON_AGE="pAge";
    public static final String PIGEON_DO_COMPETE="pCompete";
    //=========================
    public static final String LINKS_TABLE="Links";
    public static final String LINK_NAME="lName";
    public static final String LINK_ID="lID";
    public static final String LINK_TYPE="lType";



    public HelperDB(@Nullable Context context) {
        super(context, DB_FILE, null, 1);

    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String st="CREATE TABLE IF NOT EXISTS "+USERS_TABLE;
        st+=" ( "+USER_NICKNAME+" TEXT, "+USER_PASSWORD+" TEXT, ";
        st+=USER_EMAIL+" TEXT, "+USER_PHONE+" TEXT, ";
        st+=USER_BD+" TEXT);";
        db.execSQL(st);

        st = "CREATE TABLE IF NOT EXISTS " + PIGEON_TABLE;
        st += " ( " + PIGEON_CHIP_ID + " TEXT, " + PIGEON_NAME + " TEXT, ";
        st += PIGEON_SPECIES + " TEXT, " + PIGEON_AGE + " TEXT, ";
        st += PIGEON_DO_COMPETE + " TEXT);";
        db.execSQL(st);

        st = "CREATE TABLE IF NOT EXISTS " + LINKS_TABLE;
        st += " ( " + LINK_NAME + " TEXT, " + LINK_ID + " TEXT, ";
        st += LINK_TYPE + " TEXT);";
        db.execSQL(st);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }
}
