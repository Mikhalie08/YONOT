package mikhal.birova.yonot;

import static androidx.constraintlayout.motion.widget.Debug.getLocation;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Location;
import android.os.Bundle;
import android.speech.tts.TextToSpeech;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.CircleOptions;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.maps.model.PolylineOptions;

import mikhal.birova.yonot.BaseMenu;

public class WhereIsPegion extends AppCompatActivity implements OnMapReadyCallback {

    private GoogleMap mMap;
    private FusedLocationProviderClient fusedLocationClient;
    private EditText etLatitude, etLongitude;
    private TextView tvInfoPegion;
    private Button bTakeInfo;
    private double currentLat, currentLon;
    private Context context;
    ImageView ivMenuWP;
    BaseMenu baseMenu;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_where_is_pegion);

        // Запрос разрешений
        ActivityCompat.requestPermissions(this,
                new String[]{Manifest.permission.ACCESS_FINE_LOCATION,
                        Manifest.permission.ACCESS_COARSE_LOCATION},
                1);

        // Инициализация виджетов
        context = this;
        etLatitude = findViewById(R.id.etLatitude);
        etLongitude = findViewById(R.id.etLongitude);
        tvInfoPegion = findViewById(R.id.tvInfoPegion);
        bTakeInfo = findViewById(R.id.bTakeInfo);
        ivMenuWP=findViewById(R.id.ivMenuWP);
        baseMenu=new BaseMenu(context);
        ivMenuWP.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                baseMenu.showPopupMenu(v);
            }
        });

        fusedLocationClient = LocationServices.getFusedLocationProviderClient(this);

        // Map
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager().findFragmentById(R.id.map);
        if (mapFragment != null) {
            mapFragment.getMapAsync(this);
        }

        bTakeInfo.setOnClickListener(v -> handleButtonClick());
    }

    private void handleButtonClick() {
        String stLat = etLatitude.getText().toString();
        String stLon = etLongitude.getText().toString();

        if (stLat.isEmpty() || stLon.isEmpty()) {
            Toast.makeText(context, "Please enter valid coordinates", Toast.LENGTH_SHORT).show();
            if (LoginSignup.isTTS==1)  {
                TTSManager.getInstance().speak("Please enter valid coordinates",
                        TextToSpeech.QUEUE_FLUSH, null,null);
            }
            return;
        }

        try {
            double targetLat = Double.parseDouble(stLat);
            double targetLon = Double.parseDouble(stLon);
            LatLng targetLocation = new LatLng(targetLat, targetLon);

            // Add marker for add point
            mMap.addMarker(new MarkerOptions()
                    .position(targetLocation)
                    .title("Pegion Location"));

            // distance
            LatLng currentLocation = new LatLng(currentLat, currentLon);
            double distance = calculateDistance(currentLocation, targetLocation);

            // view info
            String info = "MyLat=" + currentLat + "\nMyLon=" + currentLon +
                    "\n\nPegionLat=" + targetLat + "\nPegionLon=" + targetLon +
                    "\n\nDistance=" + ((int) distance) + " m";
            tvInfoPegion.setText(info);
            if (LoginSignup.isTTS==1)  {
                TTSManager.getInstance().speak(info,
                        TextToSpeech.QUEUE_FLUSH, null,null);
            }

        } catch (NumberFormatException e) {
            Toast.makeText(context, "Invalid coordinates", Toast.LENGTH_SHORT).show();
            if (LoginSignup.isTTS==1)  {
                TTSManager.getInstance().speak("Invalid coordinates",
                        TextToSpeech.QUEUE_FLUSH, null,null);
            }
        }
    }

    private void getMyLocation() {
        if (ActivityCompat.checkSelfPermission(this,
                Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, 1);
            return;
        }
        fusedLocationClient.getLastLocation().addOnSuccessListener(location -> {
            if (location != null) {
                currentLat = location.getLatitude();
                currentLon = location.getLongitude();

                // marker my location
                LatLng currentLatLng = new LatLng(currentLat, currentLon);
                mMap.addMarker(new MarkerOptions()
                        .position(currentLatLng)
                        .title("My Location"));
                drawCircle(currentLatLng);

                /*// Добавляем круг радиусом 1000 метров
                mMap.addCircle(new CircleOptions()
                        .center(currentLatLng)
                        .radius(1000)
                        .strokeColor(0xFFFF0000) // Красная граница
                        .fillColor(0x44FF0000)   // Полупрозрачное заполнение
                        .strokeWidth(5));
*/
                // move a camera
                mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(currentLatLng, 14));
            }
        });
    }

    private double calculateDistance(LatLng start, LatLng end) {
        float[] results = new float[1];
        Location.distanceBetween(start.latitude, start.longitude, end.latitude, end.longitude, results);
        return results[0]; // distance
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == 1 && grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            getMyLocation();
        } else {
            Toast.makeText(this, "Permission denied", Toast.LENGTH_SHORT).show();
            if (LoginSignup.isTTS==1)  {
                TTSManager.getInstance().speak("Permission denied",
                        TextToSpeech.QUEUE_FLUSH, null,null);
            }
        }
    }

    @Override
    public void onMapReady(@NonNull GoogleMap googleMap) {
        mMap = googleMap;
       // getMyLocation();
        LatLng latLng = new LatLng(currentLat, currentLon); // Используйте полученные координаты
        MarkerOptions markerOptions = new MarkerOptions()
                .position(latLng)
                .title("Marker Title");
        mMap.addMarker(markerOptions); // mMap не null
    }

    private void drawCircle(LatLng center) {
        mMap.addCircle(new CircleOptions()
                .center(center)
                .radius(1000)
                .strokeColor(0xFF0000FF)
                .fillColor(0x80FF0000)
                .strokeWidth(2));
    }

}

