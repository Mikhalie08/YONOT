package mikhal.birova.yonot;

import android.content.Intent;
import android.os.Bundle;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import com.google.android.material.bottomnavigation.BottomNavigationView;

public class Home extends AppCompatActivity {
    User user;
    Intent takeIt;
    Bundle bundle;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        BottomNavigationView bottomNavigation = findViewById(R.id.bottom_navigation);
        bottomNavigation.setOnNavigationItemSelectedListener(navListener);

        takeIt=getIntent();
        user=(User) takeIt.getSerializableExtra("user");
        bundle = new Bundle();
        bundle.putSerializable("user", user);

        // Load default fragment
        if (savedInstanceState == null) {
            getSupportFragmentManager().beginTransaction()
                    .replace(R.id.fragment_container, new MyPegionsFragment())
                    .commit();
        }
    }

    private final BottomNavigationView.OnNavigationItemSelectedListener navListener =
            item -> {
                Fragment selectedFragment = null;
                if (item.getItemId()==R.id.nav_secondhand) {
                    selectedFragment = new SecondHandFragment();
                    selectedFragment.setArguments(bundle);
                }
                if (item.getItemId()==R.id.nav_mypigeons)  {
                    selectedFragment = new MyPegionsFragment();
                    selectedFragment.setArguments(bundle);
                }
                if (item.getItemId()==R.id.nav_links)  {
                    selectedFragment = new LinksCollectionFragment();
                    selectedFragment.setArguments(bundle);
                }
                if (selectedFragment != null) {
                    getSupportFragmentManager().beginTransaction()
                            .replace(R.id.fragment_container, selectedFragment)
                            .commit();
                }
                return true;
            };
}
