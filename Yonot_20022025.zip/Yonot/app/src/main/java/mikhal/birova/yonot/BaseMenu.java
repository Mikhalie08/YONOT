package mikhal.birova.yonot;

import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.speech.tts.TextToSpeech;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.PopupMenu;
import android.widget.Toast;

public class BaseMenu {

    private final Context context;
    //private BatteryStatusReceiver batteryReceiver;
    //private ChargerConnectionReceiver chargerConnectionReceiver=new ChargerConnectionReceiver();

    public BaseMenu(Context context) {
        this.context = context;
    }

    public void showPopupMenu(View anchorView) {
        PopupMenu popupMenu = new PopupMenu(context, anchorView);
        MenuInflater inflater = popupMenu.getMenuInflater();
        inflater.inflate(R.menu.main_menu, popupMenu.getMenu());

        popupMenu.setOnMenuItemClickListener(this::handleMenuItemClick);

        popupMenu.show();
    }

    public boolean handleMenuItemClick(MenuItem item) {
        int id = item.getItemId();

        if (id == R.id.action_tts_check) {
            item.setChecked(!item.isChecked());
            if (item.isChecked()) {
                LoginSignup.isTTS=1;
                Toast.makeText(context, "TextToSpeech ON", Toast.LENGTH_LONG).show();
            } else {
                LoginSignup.isTTS=0;
                Toast.makeText(context, "TextToSpeech OFF", Toast.LENGTH_SHORT).show();
            }
            return true;
        }

        if (id == R.id.action_reminder) {
            Toast.makeText(context, "Reminder", Toast.LENGTH_SHORT).show();
            Intent intent = new Intent(context, Reminder.class);
            context.startActivity(intent);
            return true;
        }

        if (id == R.id.action_go_back) {
            if (context instanceof android.app.Activity) {
                android.app.Activity activity = (android.app.Activity) context;

                if (activity instanceof androidx.fragment.app.FragmentActivity) {
                    androidx.fragment.app.FragmentActivity fragmentActivity = (androidx.fragment.app.FragmentActivity) activity;
                    if (fragmentActivity.getSupportFragmentManager().getBackStackEntryCount() > 0) {
                        fragmentActivity.getSupportFragmentManager().popBackStack();
                    } else {
                        activity.finish();
                    }
                } else {
                    activity.finish();
                }
            }
            Toast.makeText(context, "Return to previos screen", Toast.LENGTH_SHORT).show();
            TTSManager.getInstance().speak("Return to previos screen",
                    TextToSpeech.QUEUE_FLUSH,null,null);
            return true;
        }


        if (id == R.id.action_exit) {
            Toast.makeText(context, "Exit from application", Toast.LENGTH_SHORT).show();
            if (context instanceof android.app.Activity) {
                ((android.app.Activity) context).finishAffinity();
            }
            return true;
        }

        if (id == R.id.action_restart) {
            Toast.makeText(context, "Restart application", Toast.LENGTH_SHORT).show();
            Intent intent = context.getPackageManager()
                    .getLaunchIntentForPackage(context.getPackageName());
            if (intent != null) {
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                context.startActivity(intent);
            }
            return true;
        }

        if (id == R.id.action_about)  {
            Toast.makeText(context, "About application", Toast.LENGTH_SHORT).show();
            TTSManager.getInstance().speak("About application", TextToSpeech.QUEUE_FLUSH,null,null);
            Intent intent = new Intent(context, AboutMe.class);
            context.startActivity(intent);
            return true;
        }
        return false;
    }
}
