package mikhal.birova.yonot;

import static java.security.AccessController.getContext;

import android.content.Context;
import android.os.Bundle;
import android.util.TypedValue;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

public class Guide extends AppCompatActivity {

    Context context;
    LinearLayout LL_guide;
    int n = 4;
    private final Button[] buttons = new Button[n];
    private final TextView[] textViews = new TextView[n];
    private ImageView ivMenuGuide;
    private BaseMenu baseMenu;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_guide);

        context = this;

        ivMenuGuide=findViewById(R.id.ivMenuGuide);
        baseMenu=new BaseMenu(this);
        ivMenuGuide.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                baseMenu.showPopupMenu(v);
            }
        });

        LL_guide = findViewById(R.id.LL_guide);

        int[] rawFiles = {R.raw.part1, R.raw.part2, R.raw.part3, R.raw.part4};

        for (int i = 0; i < n; i++) {
            int widthInPx = (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP,
                    300, getResources().getDisplayMetrics());

            // Создаем Button
            Button button = new Button(context);
            button.setText("Button " + (i + 1));
            LinearLayout.LayoutParams buttonParams = new LinearLayout.LayoutParams(
                    widthInPx,
                    LinearLayout.LayoutParams.WRAP_CONTENT);
            buttonParams.bottomMargin = 30;
            button.setLayoutParams(buttonParams);

            // Создаем TextView
            TextView textView = new TextView(context);
            textView.setText(readTextFromRaw(rawFiles[i])); // Устанавливаем текст из ресурса
            textView.setLayoutParams(new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT));
            textView.setVisibility(View.GONE);

            // Добавляем обработчик нажатия на Button
            final int index = i;
            button.setOnClickListener(v -> {
                if (textViews[index].getVisibility() == View.GONE) {
                    textViews[index].setVisibility(View.VISIBLE);
                } else {
                    textViews[index].setVisibility(View.GONE);
                }
            });

            // Добавляем элементы в разметку
            LL_guide.addView(button);
            LL_guide.addView(textView);

            // Сохраняем ссылки на элементы
            buttons[i] = button;
            textViews[i] = textView;
        }
    }

    // Метод для чтения текстов из ресурсов raw
    private String readTextFromRaw(int resourceId) {
        StringBuilder text = new StringBuilder();
        try {
            InputStream inputStream = getResources().openRawResource(resourceId);
            BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream));
            String line;
            while ((line = reader.readLine()) != null) {
                text.append(line).append("\n");
            }
            reader.close();
        } catch (IOException e) {
            e.printStackTrace();
            text.append("Ошибка чтения ресурса ID: ").append(resourceId);
        }
        return text.toString();
    }
}
