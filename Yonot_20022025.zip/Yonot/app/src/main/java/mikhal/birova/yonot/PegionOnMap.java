package mikhal.birova.yonot;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Location;
import android.os.Bundle;
import android.speech.tts.TextToSpeech;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.activity.result.ActivityResultLauncher;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.fragment.app.FragmentTransaction;

import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;

public class PegionOnMap extends AppCompatActivity {

    Context context;
    EditText etMyLon, etMyLat;
    TextView tvSummaryInfo;
    Button bSumInfo;
    private double currentLat, currentLon, targetLat, targetLon, distance;
    private FusedLocationProviderClient fusedLocationClient;
    private LatLng currentLatLng, targetLatLon;
    String info="";
    FrameLayout FLforF;
    TraceFragment traceFragment;
    private GoogleMap mMap;
    private ActivityResultLauncher<Intent> mapLauncher;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pegion_on_map);

        ActivityCompat.requestPermissions(this,
                new String[]{android.Manifest.permission.ACCESS_FINE_LOCATION,
                        Manifest.permission.ACCESS_COARSE_LOCATION},
                1);

        initComponents();

        bSumInfo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String stLat = etMyLat.getText().toString();
                String stLon = etMyLon.getText().toString();

                if (stLat.isEmpty() || stLon.isEmpty()) {
                    Toast.makeText(context,
                            "Please enter valid coordinates", Toast.LENGTH_SHORT).show();
                    if (LoginSignup.isTTS==1)  {
                        TTSManager.getInstance().speak("Please enter valid coordinates",
                                TextToSpeech.QUEUE_FLUSH, null,null);
                    }
                    return;
                }

                try {
                    targetLat = Double.parseDouble(stLat);
                    targetLon = Double.parseDouble(stLon);
                    info+="PegionLat=" + targetLat + "\nPegionLon=" + targetLon+"\n------------\n\n";
                    targetLatLon = new LatLng(targetLat, targetLon);
                    distance = calculateDistance(currentLatLng, targetLatLon);
                    info+="Distance=" + ((int) distance) + " m";
                    if (LoginSignup.isTTS==1)  {
                        TTSManager.getInstance().speak("Distance=" + ((int) distance) + " m",
                                TextToSpeech.QUEUE_FLUSH, null,null);
                    }
                    tvSummaryInfo.setText(info);

                } catch (NumberFormatException e) {
                    Toast.makeText(context, "Invalid coordinates", Toast.LENGTH_SHORT).show();
                    if (LoginSignup.isTTS==1)  {
                        TTSManager.getInstance().speak("Invalid coordinates",
                                TextToSpeech.QUEUE_FLUSH, null,null);
                    }
                }
            }
        });
    }

    private void getMyLocation() {
        if (ActivityCompat.checkSelfPermission(this,
                Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, 1);
            return;
        }
        fusedLocationClient.getLastLocation().addOnSuccessListener(location -> {
            if (location != null) {
                currentLat = location.getLatitude();
                currentLon = location.getLongitude();
                currentLatLng = new LatLng(currentLat, currentLon);
                info+="MyLat="+currentLat+"\nMyLon="+currentLon+"\n---------------\n";
                tvSummaryInfo.setText(info);
                if (LoginSignup.isTTS==1)  {
                    TTSManager.getInstance().speak("MyLat="+currentLat+"\nMyLon="+currentLon,
                            TextToSpeech.QUEUE_FLUSH, null,null);
                }
            }
            else {
                tvSummaryInfo.setText("Error");
                if (LoginSignup.isTTS==1)  {
                    TTSManager.getInstance().speak("Error",
                            TextToSpeech.QUEUE_FLUSH, null,null);
                }
            }
        });

    }

    private double calculateDistance(LatLng start, LatLng end) {
        float[] results = new float[1];
        Location.distanceBetween(start.latitude, start.longitude, end.latitude, end.longitude, results);
        return results[0]; // Расстояние в метрах
    }

    private void initComponents() {
        context=this;
        FLforF=findViewById(R.id.FLforF);
        etMyLat=findViewById(R.id.etMyLat);
        etMyLon=findViewById(R.id.etMyLon);
        tvSummaryInfo=findViewById(R.id.tvSummaryInfo);
        bSumInfo=findViewById(R.id.bSumInfo);
        traceFragment=new TraceFragment();
        FragmentTransaction ft=getSupportFragmentManager().beginTransaction();
        ft.replace(R.id.FLforF, traceFragment);
        ft.commit();

        fusedLocationClient = LocationServices.getFusedLocationProviderClient(this);
        getMyLocation();
    }
}