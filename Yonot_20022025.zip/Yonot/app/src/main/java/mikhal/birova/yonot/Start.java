package mikhal.birova.yonot;

import android.annotation.TargetApi;
import android.content.ContentValues;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.database.DatabaseUtils;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Bitmap;
import android.os.Build;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.speech.tts.TextToSpeech;
import android.view.View;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Locale;

public class Start extends AppCompatActivity {

    Context context;
    ImageView ivLogo;
    CountDownTimer cdt;
    HelperDB helperDB;
    SQLiteDatabase db;
    int count=0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_start);

        initComponents();
        //ivLogo.animate().setDuration(4000).rotation(720).start();
        //ivLogo.animate().setDuration(4000).translationY(400).start();

        cdt=new CountDownTimer(4000, 1000) {
            @Override
            public void onTick(long millisUntilFinished) {
                if (count==0)  {
                    helperDB=new HelperDB(context);
                    db=helperDB.getWritableDatabase();
                    db.close();
                    count++;
                }
            }

            @Override
            public void onFinish() {
                Intent go=new Intent(context, LoginSignup.class);
                startActivity(go);
            }
        }.start();
    }

    private void initComponents() {
        context=this;
        ivLogo=findViewById(R.id.ivLogo);
        helperDB=new HelperDB(context);
        TTSManager.getInstance().init(context);db=helperDB.getWritableDatabase();
        long linksCount= DatabaseUtils.queryNumEntries(db,HelperDB.LINKS_TABLE);
        if (linksCount==0)
            startCopyLincs();
        else
            db.close();

    }

    private void startCopyLincs() {
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    InputStream inputStream = getResources().openRawResource(R.raw.start_links);
                    BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream));
                    String st1 = "", st2 = "", st3 = "";
                    final ArrayList<Link> a = new ArrayList<>();

                    while ((st1 = reader.readLine()) != null) {
                        st2 = reader.readLine();
                        st3 = reader.readLine();
                        ContentValues cv = new ContentValues();
                        cv.put(helperDB.LINK_NAME, st1);
                        cv.put(helperDB.LINK_ID, st2);
                        cv.put(helperDB.LINK_TYPE, st3);
                        a.add(new Link(st1, st2, st3));
                        db.insert(helperDB.LINKS_TABLE, null, cv);
                    }
                    reader.close();
                    db.close();

                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            Toast.makeText(context,
                                    "Finish of coping " + a.size()+" links in DB",
                                    Toast.LENGTH_SHORT).show();
                        }
                    });

                } catch (final IOException e) {
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            e.printStackTrace();
                            Toast.makeText(context, "Error: " + e.getMessage(),
                                    Toast.LENGTH_SHORT).show();
                        }
                    });
                }
            }
        }).start();
    }
}