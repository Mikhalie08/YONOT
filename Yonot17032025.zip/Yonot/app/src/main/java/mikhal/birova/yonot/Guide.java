package mikhal.birova.yonot;

import static java.security.AccessController.getContext;

import android.content.Context;
import android.os.Bundle;
import android.util.TypedValue;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

public class Guide extends AppCompatActivity {

    Context context;
    LinearLayout LL_guide;
    int n = 4;
    private final Button[] buttons = new Button[n];
    private ImageView ivMenuGuide;
    private BaseMenu baseMenu;
    int[] rawFiles = {R.raw.part1, R.raw.part2, R.raw.part3, R.raw.part4};
    String[] buttonText={"Core Features for Pigeon Breeders",
            "Additional Categories Beyond Your Own Pigeons",
            "How to Register","What is a Pigeon Chi"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_guide);

        context = this;

        ivMenuGuide=findViewById(R.id.ivMenuGuide);
        baseMenu=new BaseMenu(this);
        ivMenuGuide.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                baseMenu.showPopupMenu(v);
            }
        });

        LL_guide = findViewById(R.id.LL_guide);

        for (int i = 0; i < n; i++) {
            int widthInPx = (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP,
                    300, getResources().getDisplayMetrics());

            Button button = new Button(context);
            button.setText(buttonText[i]);
            LinearLayout.LayoutParams buttonParams = new LinearLayout.LayoutParams(
                    widthInPx,
                    LinearLayout.LayoutParams.WRAP_CONTENT);
            buttonParams.bottomMargin = 30;
            button.setLayoutParams(buttonParams);
            final int index = i;
            button.setOnClickListener(v -> {
                AlertDialog.Builder builder = new AlertDialog.Builder(context);
                builder.setTitle(buttonText[index]);
                builder.setMessage(readTextFromRaw(rawFiles[index]));
                builder.setPositiveButton("OK", null);
                builder.show();
            });

            LL_guide.addView(button);

            buttons[i] = button;

        }
    }

    private String readTextFromRaw(int resourceId) {
        StringBuilder text = new StringBuilder();
        try {
            InputStream inputStream = getResources().openRawResource(resourceId);
            BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream));
            String line;
            while ((line = reader.readLine()) != null) {
                text.append(line).append("\n");
            }
            reader.close();
        } catch (IOException e) {
            e.printStackTrace();
            text.append("Errer reading raw file").append(resourceId);
        }
        return text.toString();
    }
}
