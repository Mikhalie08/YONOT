package mikhal.birova.yonot;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.FrameLayout;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.fragment.app.FragmentTransaction;

public class TraceForDemo extends AppCompatActivity {

    Button bStopTrace;
    FrameLayout trace_conteiner;
    TraceFragment traceFragment = new TraceFragment();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_trace_for_demo);

        trace_conteiner=findViewById(R.id.trace_conteiner);
        getSupportFragmentManager().beginTransaction()
                .replace(R.id.trace_conteiner, traceFragment)
                .commit();
        /*TraceFragment traceFragment = new TraceFragment();
        FragmentTransaction ft = getSupportFragmentManager().beginTransaction();
        ft.replace(R.id.fragment_container, traceFragment);
        ft.commit();*/

        bStopTrace = findViewById(R.id.bStopTrace);
        bStopTrace.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }
}