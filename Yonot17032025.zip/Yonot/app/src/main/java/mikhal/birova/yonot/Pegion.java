package mikhal.birova.yonot;

import java.io.Serializable;

class Pegion implements Serializable {
    private String Chip;
    private String Name;
    private String Species;
    private String Age;
    private String Compete;

    public Pegion(String chip, String name, String species, String age, String compete) {
        Chip = chip;
        Name = name;
        Species = species;
        Age = age;
        Compete = compete;
    }

    public String getChip() {
        return Chip;
    }

    public void setChip(String chip) {
        Chip = chip;
    }

    public String getName() {
        return Name;
    }

    public void setName(String name) {
        Name = name;
    }

    public String getSpecies() {
        return Species;
    }

    public void setSpecies(String species) {
        Species = species;
    }

    public String getAge() {
        return Age;
    }

    public void setAge(String age) {
        Age = age;
    }

    public String getCompete() {
        return Compete;
    }

    public void setCompete(String compete) {
        Compete = compete;
    }

    @Override
    public String toString() {
        return "Pegion{" +
                "Chip='" + Chip + '\'' +
                ", Name='" + Name + '\'' +
                ", Species='" + Species + '\'' +
                ", Age='" + Age + '\'' +
                ", Compete='" + Compete + '\'' +
                '}';
    }
}
