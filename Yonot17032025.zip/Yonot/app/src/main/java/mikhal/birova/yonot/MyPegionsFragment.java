package mikhal.birova.yonot;

import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Color;
import android.os.Bundle;

import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.Fragment;

import android.os.Handler;
import android.speech.tts.TextToSpeech;
import android.view.GestureDetector;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.ProgressBar;
import androidx.appcompat.widget.SearchView;
import android.widget.Toast;

import java.util.ArrayList;

public class MyPegionsFragment extends Fragment {

    ImageView ivAddP, ivFindP;
    ListView lvPegions;
    ArrayList<Pegion> all_pegions;
    ArrayList<String> pegions_names;
    ArrayAdapter<String> adapter;
    HelperDB helperDB;
    SQLiteDatabase db;
    Pegion pegion;
    int count_rows=0;
    ProgressBar progressBar;
    Handler handler;
    SearchView searchView;
    ImageView ivMenu;
    BaseMenu baseMenu;
    Bundle arguments;
    User user;
    String[] data = {
            "😊 Smile",
            "🚀 Rocket",
            "🍕 Pizza",
            "🐶 Dog",
            "🌟 Star"
    };
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view=inflater.inflate(R.layout.fragment_my_pegions, container, false);

        user=new User("","","","","");
        arguments=getArguments();
        if (arguments!=null)  {
           user=(User) arguments.getSerializable("user");
        }
        ivMenu=view.findViewById(R.id.ivMenuPF);
        baseMenu=new BaseMenu(getContext());
        ivMenu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                baseMenu.showPopupMenu(v);
            }
        });

        progressBar = view.findViewById(R.id.progressBar);
        lvPegions=view.findViewById(R.id.lvPegions);
        searchView=view.findViewById(R.id.searchView);
        buildPegionsList();

        lvPegions.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                pegion=all_pegions.get(position);
                update_or_delete(pegion);
            }
        });

        // Setting up GestureDetector
        GestureDetector gestureDetector = new GestureDetector(requireContext(), new GestureDetector.SimpleOnGestureListener() {
            @Override
            public boolean onFling(MotionEvent e1, MotionEvent e2, float velocityX, float velocityY) {
                if (e1.getX() < e2.getX() && Math.abs(e1.getY() - e2.getY()) < 100) { // Swipe righthand
                    int position = lvPegions.pointToPosition((int) e1.getX(), (int) e1.getY());
                    if (position != AdapterView.INVALID_POSITION) {
                        onSwipeRight(position);
                    }
                    return true;
                }
                return false;
            }
        });

        lvPegions.setOnTouchListener((v, event) -> gestureDetector.onTouchEvent(event));

        ivAddP=view.findViewById(R.id.ivAddP);
        ivAddP.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                pegion_add();
            }
        });

        ivFindP=view.findViewById(R.id.ivFindP);
        ivFindP.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                find_pegion();
            }
        });

        return view;
    }

    private void find_pegion() {
        searchView.setVisibility(View.VISIBLE);
        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                return false;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                ArrayList<Pegion> filteredPegion=new ArrayList<>();
                ArrayList<String> filteredList = new ArrayList<>();
                for (Pegion pegion : all_pegions) {
                    if (pegion.getName().toLowerCase().contains(newText.toLowerCase())) {
                        filteredPegion.add(pegion);
                        filteredList.add(pegion.getName() + " (" + pegion.getChip() + ")");
                    }
                }
                adapter.clear();
                adapter.addAll(filteredList);
                adapter.notifyDataSetChanged();
                return true;
            }
        });
    }

    private void update_or_delete(Pegion pegion) {
        AlertDialog.Builder adb=new AlertDialog.Builder(getContext());
        adb.setCancelable(false);

        final View my_alertdialog = getLayoutInflater().inflate(R.layout.update_pegion, null);
        adb.setView(my_alertdialog);

        EditText etPchip=my_alertdialog.findViewById(R.id.etPchip);
        EditText etPname=my_alertdialog.findViewById(R.id.etPname);
        EditText etPspecies=my_alertdialog.findViewById(R.id.etPspecies);
        EditText etPage=my_alertdialog.findViewById(R.id.etPage);
        EditText etPcompete=my_alertdialog.findViewById(R.id.etPCompete);

        etPchip.setText(pegion.getChip());
        etPname.setText(pegion.getName());
        etPspecies.setText(pegion.getSpecies());
        etPage.setText(pegion.getAge());
        etPcompete.setText(pegion.getCompete());

        Button bUpdate=my_alertdialog.findViewById(R.id.bUpdate);
        Button bDelete=my_alertdialog.findViewById(R.id.bDelete);
        Button bAdd=my_alertdialog.findViewById(R.id.bAdd);
        Button bCancel=my_alertdialog.findViewById(R.id.bCancel);

        bAdd.setVisibility(View.GONE);

        final AlertDialog ad=adb.show();

        bUpdate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String stChip=etPchip.getText().toString();
                String stName=etPname.getText().toString();
                String stSpecies=etPspecies.getText().toString();
                String stAge=etPage.getText().toString();
                String stCompete=etPcompete.getText().toString();
                ContentValues cv=new ContentValues();
                cv.put(helperDB.PIGEON_CHIP_ID, stChip);
                cv.put(helperDB.PIGEON_NAME, stName);
                cv.put(helperDB.PIGEON_SPECIES, stSpecies);
                cv.put(helperDB.PIGEON_AGE, stAge);
                cv.put(helperDB.PIGEON_DO_COMPETE, stCompete);
                helperDB=new HelperDB(getContext());
                db=helperDB.getWritableDatabase();
                String whereClause = helperDB.PIGEON_CHIP_ID + " = ?";
                String[] whereArgs = { pegion.getChip() };
                int rowsAffected = db.update(helperDB.PIGEON_TABLE, cv, whereClause, whereArgs);
                if (rowsAffected > 0) {
                    My_Toast.showToast(getContext(),"Update is Ok",12);
                    if (LoginSignup.isTTS==1)  {
                        TTSManager.getInstance().speak("Update is Ok",
                                TextToSpeech.QUEUE_FLUSH, null, null);
                    }
                } else {
                    My_Toast.showToast(getContext(),"Error in update",11);
                    if (LoginSignup.isTTS==1)
                        TTSManager.getInstance().speak("Error in update",
                                TextToSpeech.QUEUE_FLUSH,null,null);
                }
                db.close();
                buildPegionsList();
            }
        });

        bDelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String stChip=etPchip.getText().toString();
                helperDB=new HelperDB(getContext());
                db=helperDB.getWritableDatabase();
                db.delete(helperDB.PIGEON_TABLE,
                        helperDB.PIGEON_CHIP_ID+"=?",
                        new String[]{stChip});
                db.close();
                buildPegionsList();
                Toast.makeText(getContext(), "End deleting", Toast.LENGTH_SHORT).show();
                if (LoginSignup.isTTS==1)
                    TTSManager.getInstance().speak("End deleting",
                            TextToSpeech.QUEUE_FLUSH,null,null);
                ad.dismiss();
            }
        });

        bCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ad.dismiss();
            }
        });
    }

    private void pegion_add() {
        AlertDialog.Builder adb=new AlertDialog.Builder(getContext());
        adb.setCancelable(false);

        final View my_alertdialog = getLayoutInflater().inflate(R.layout.update_pegion, null);
        adb.setView(my_alertdialog);

        EditText etPchip=my_alertdialog.findViewById(R.id.etPchip);
        EditText etPname=my_alertdialog.findViewById(R.id.etPname);
        EditText etPspecies=my_alertdialog.findViewById(R.id.etPspecies);
        EditText etPage=my_alertdialog.findViewById(R.id.etPage);
        EditText etPcompete=my_alertdialog.findViewById(R.id.etPCompete);

        Button bUpdate=my_alertdialog.findViewById(R.id.bUpdate);
        Button bDelete=my_alertdialog.findViewById(R.id.bDelete);
        Button bAdd=my_alertdialog.findViewById(R.id.bAdd);
        Button bCancel=my_alertdialog.findViewById(R.id.bCancel);

        bUpdate.setVisibility(View.GONE);
        bDelete.setVisibility(View.GONE);

        final AlertDialog ad=adb.show();

        bAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String stChip=etPchip.getText().toString();
                String stName=etPname.getText().toString();
                String stSpecies=etPspecies.getText().toString();
                String stAge=etPage.getText().toString();
                String stCompete=etPcompete.getText().toString();
                if (!foundID(stChip)) {
                    helperDB = new HelperDB(getContext());
                    ContentValues cv = new ContentValues();
                    cv.put(helperDB.PIGEON_CHIP_ID, stChip);
                    cv.put(helperDB.PIGEON_NAME, stName);
                    cv.put(helperDB.PIGEON_SPECIES, stSpecies);
                    cv.put(helperDB.PIGEON_AGE, stAge);
                    cv.put(helperDB.PIGEON_DO_COMPETE, stCompete);
                    db = helperDB.getWritableDatabase();
                    db.insert(helperDB.PIGEON_TABLE, null, cv);
                    db.close();
                    buildPegionsList();
                    ad.dismiss();
                }
                else {
                    My_Toast.showToast(getContext(),"Chip ID is found",11);
                    if (LoginSignup.isTTS==1)
                        TTSManager.getInstance().speak("Chip ID is found",
                                TextToSpeech.QUEUE_FLUSH,null,null);
                }
            }
        });
        bCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ad.dismiss();
            }
        });
    }

    private boolean foundID(String stChip) {
        helperDB=new HelperDB(getContext());
        db=helperDB.getReadableDatabase();
        Cursor cursor=db.query(helperDB.PIGEON_TABLE,
                null,null,null,
                null,null,null);
        if (cursor.getCount()==0) {
            db.close();
            return false;
        }
        cursor.moveToFirst();
        while (!cursor.isAfterLast())  {
            String st=cursor.getString((int)cursor.getColumnIndex(helperDB.PIGEON_CHIP_ID));
            if (st.equals(stChip))  {
                db.close();
                return true;
            }
            cursor.moveToNext();
        }
        db.close();
        return false;
    }

    private void buildPegionsList() {
        handler=new Handler();
        //progressBar.setVisibility(View.VISIBLE);

        new Thread(new Runnable() {
            @Override
            public void run() {
                all_pegions=new ArrayList<>();
                pegions_names=new ArrayList<>();
                helperDB=new HelperDB(getContext());
                db=helperDB.getReadableDatabase();
                Cursor cursor=db.query(helperDB.PIGEON_TABLE,
                        null,null,null,
                        null,null,null);
                count_rows=cursor.getCount();
                if (count_rows==0) {
                    db.close();
                    return;
                }
                cursor.moveToFirst();
                while (!cursor.isAfterLast())  {
                    String stChip=cursor.getString((int)cursor.getColumnIndex(helperDB.PIGEON_CHIP_ID));
                    String stName=cursor.getString((int)cursor.getColumnIndex(helperDB.PIGEON_NAME));
                    String stSpecies=cursor.getString((int)cursor.getColumnIndex(helperDB.PIGEON_SPECIES));
                    String stAge=cursor.getString((int)cursor.getColumnIndex(helperDB.PIGEON_AGE));
                    String stCompete=cursor.getString((int)cursor.getColumnIndex(helperDB.PIGEON_DO_COMPETE));
                    Pegion pegion=new Pegion(stChip,stName,stSpecies, stAge,stCompete);
                    all_pegions.add(pegion);
                    pegions_names.add(data[0]+pegion.getName()+" ("+pegion.getChip()+")");
                    cursor.moveToNext();
                }
                db.close();

                handler.post(new Runnable() {
                    @Override
                    public void run() {
                        if (count_rows==0) {
                            My_Toast.showToast(getContext(), "Database of pegions is empty", 11);
                            if (LoginSignup.isTTS==1)
                                TTSManager.getInstance().speak("Database of pegions is empty",
                                        TextToSpeech.QUEUE_FLUSH,null,null);
                            progressBar.setVisibility(View.GONE);
                        }
                        else {
                            adapter=new ArrayAdapter<>(getContext(),
                                    android.R.layout.simple_list_item_1,
                                    pegions_names);
                            lvPegions.setAdapter(adapter);
                            adapter.notifyDataSetChanged();
                        }
                        progressBar.setVisibility(View.GONE);
                    }
                });
            }
        }).start();
    }

    private void onSwipeRight(int position) {
        Pegion pegion = all_pegions.get(position);
        Intent go=new Intent(requireContext(), WhereIsPegion.class);
        go.putExtra("pegion",pegion);
        go.putExtra("user",user);
        startActivity(go);
        //pegions_names.remove(position);
        //adapter.notifyDataSetChanged();
    }
}