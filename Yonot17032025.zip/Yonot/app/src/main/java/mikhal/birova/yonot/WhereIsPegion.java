package mikhal.birova.yonot;

import static androidx.constraintlayout.motion.widget.Debug.getLocation;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Location;
import android.os.Bundle;
import android.speech.tts.TextToSpeech;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.fragment.app.FragmentTransaction;

import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.CircleOptions;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.LatLngBounds;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.maps.model.PolylineOptions;

import mikhal.birova.yonot.BaseMenu;

public class WhereIsPegion extends AppCompatActivity implements OnMapReadyCallback {

    private GoogleMap mMap;
    private FusedLocationProviderClient fusedLocationClient;
    private EditText etLatitude, etLongitude;
    private TextView tvInfoPegion;
    private Button bTakeInfo, bDemoTrace;
    private double currentLat, currentLon;
    private Context context;
    ImageView ivMenuWP;
    BaseMenu baseMenu;
    private LatLng targetLocation, currentLocation;
    String info="",add_info="";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_where_is_pegion);

        ActivityCompat.requestPermissions(this,
                new String[]{Manifest.permission.ACCESS_FINE_LOCATION,
                        Manifest.permission.ACCESS_COARSE_LOCATION},
                1);

        context = this;
        etLatitude = findViewById(R.id.etLatitude);
        etLongitude = findViewById(R.id.etLongitude);
        tvInfoPegion = findViewById(R.id.tvInfoPegion);
        bTakeInfo = findViewById(R.id.bTakeInfo);
        ivMenuWP=findViewById(R.id.ivMenuWP);
        baseMenu=new BaseMenu(context);

        ivMenuWP.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                baseMenu.showPopupMenu(v);
            }
        });

        fusedLocationClient = LocationServices.getFusedLocationProviderClient(this);

        // Map
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager().findFragmentById(R.id.map);
        if (mapFragment != null) {
            mapFragment.getMapAsync(this);
        }

        bTakeInfo.setOnClickListener(v -> handleButtonClick());

        bDemoTrace = findViewById(R.id.bDemoTrace);
        bDemoTrace.setOnClickListener(v -> {
            Intent intent = new Intent(WhereIsPegion.this, TraceForDemo.class);
            startActivity(intent);
        });
    }

    private void handleButtonClick() {
        String stLat = etLatitude.getText().toString();
        String stLon = etLongitude.getText().toString();

        if (stLat.isEmpty() || stLon.isEmpty()) {
            Toast.makeText(context, "Please enter valid coordinates", Toast.LENGTH_SHORT).show();
            if (LoginSignup.isTTS==1)  {
                TTSManager.getInstance().speak("Please enter valid coordinates",
                        TextToSpeech.QUEUE_FLUSH, null,null);
            }
            return;
        }

        try {
            double targetLat = Double.parseDouble(stLat);
            double targetLon = Double.parseDouble(stLon);
            targetLocation = new LatLng(targetLat, targetLon);

            // Add marker for add point
            mMap.addMarker(new MarkerOptions()
                    .position(targetLocation)
                    .title("Pegion Location")
                    .icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_BLUE))); // Синий маркер

            // distance
            currentLocation = new LatLng(currentLat, currentLon);
            double distance = calculateDistance(currentLocation, targetLocation);

            mMap.addPolyline(new PolylineOptions()
                    .add(currentLocation, targetLocation)
                    .width(5)
                    .color(0xFF000000)); // Черная линия

            // view info
            String info = "MyLat=" + currentLat + ", MyLon=" + currentLon +
                    "\nPegionLat=" + targetLat + ",PegionLon=" + targetLon +
                    "\nDistance=" + ((int) distance) + " m";
            tvInfoPegion.setText(info);
            if (LoginSignup.isTTS==1)  {
                TTSManager.getInstance().speak(info,
                        TextToSpeech.QUEUE_FLUSH, null,null);
            }

            // Автоподгонка масштаба
            fitMapToMarkers();

        } catch (NumberFormatException e) {
            Toast.makeText(context, "Invalid coordinates", Toast.LENGTH_SHORT).show();
            if (LoginSignup.isTTS==1)  {
                TTSManager.getInstance().speak("Invalid coordinates",
                        TextToSpeech.QUEUE_FLUSH, null,null);
            }
        }
    }

    private void getMyLocation() {
        if (ActivityCompat.checkSelfPermission(this,
                Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, 1);
            return;
        }
        fusedLocationClient.getLastLocation().addOnSuccessListener(location -> {
            if (location != null) {
                currentLat = location.getLatitude();
                currentLon = location.getLongitude();

                info="MyLat="+currentLat+", MyLon="+currentLon;
                tvInfoPegion.setText(info);
                if (LoginSignup.isTTS==1)  {
                    TTSManager.getInstance().speak("MyLat="+currentLat+"\nMyLon="+currentLon,
                            TextToSpeech.QUEUE_FLUSH, null,null);
                }

                // marker my location
                LatLng currentLatLng = new LatLng(currentLat, currentLon);
                mMap.addMarker(new MarkerOptions()
                        .position(currentLatLng)
                        .title("My Location"));
                drawCircle(currentLatLng);

                // Добавляем круг радиусом 1000 метров
                mMap.addCircle(new CircleOptions()
                        .center(currentLatLng)
                        .radius(1000)
                        .strokeColor(0xFFFF0000) // Красная граница
                        .fillColor(0x4400FF00)   // Полупрозрачное заполнение
                        .strokeWidth(5));

                // move a camera
                mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(currentLatLng, 12));
                //fitMapToMarkers();
            }
        });
    }

    private void fitMapToMarkers() {
        if (currentLocation == null || targetLocation == null) return;

        LatLngBounds.Builder builder = new LatLngBounds.Builder();
        builder.include(currentLocation);
        builder.include(targetLocation);

        LatLngBounds bounds = builder.build();
        int padding = 100; // Отступы (в пикселях)
        mMap.animateCamera(CameraUpdateFactory.newLatLngBounds(bounds, padding));
    }


    private double calculateDistance(LatLng start, LatLng end) {
        float[] results = new float[1];
        Location.distanceBetween(start.latitude, start.longitude, end.latitude, end.longitude, results);
        return results[0]; // distance
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == 1 && grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            getMyLocation();
        } else {
            Toast.makeText(this, "Permission denied", Toast.LENGTH_SHORT).show();
            if (LoginSignup.isTTS==1)  {
                TTSManager.getInstance().speak("Permission denied",
                        TextToSpeech.QUEUE_FLUSH, null,null);
            }
        }
    }

    @Override
    public void onMapReady(@NonNull GoogleMap googleMap) {
        mMap = googleMap;
       // getMyLocation();
        LatLng latLng = new LatLng(currentLat, currentLon);
        MarkerOptions markerOptions = new MarkerOptions()
                .position(latLng)
                .title("Marker Title");
        mMap.addMarker(markerOptions); // mMap не null
    }

    private void drawCircle(LatLng center) {
        mMap.addCircle(new CircleOptions()
                .center(center)
                .radius(1000)
                .strokeColor(0xFF0000FF)
                .fillColor(0x8000FF00)
                .strokeWidth(2));
    }
}

