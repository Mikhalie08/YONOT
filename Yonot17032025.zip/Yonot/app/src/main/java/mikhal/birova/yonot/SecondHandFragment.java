package mikhal.birova.yonot;

import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;


public class SecondHandFragment extends Fragment {

    private LinearLayout LLSH;

    private ImageView ivMenuSHF;
    private BaseMenu baseMenu;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view= inflater.inflate(R.layout.fragment_second_hand, container, false);

        ivMenuSHF=view.findViewById(R.id.ivMenuSHF);
        baseMenu=new BaseMenu(getContext());
        ivMenuSHF.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                baseMenu.showPopupMenu(v);
            }
        });

        return view;
    }
}