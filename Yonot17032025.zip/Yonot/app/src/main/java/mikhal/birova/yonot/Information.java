package mikhal.birova.yonot;

import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class Information extends AppCompatActivity {

    Context context;
    ImageView ivMenuInfo;
    private BaseMenu baseMenu;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_information);

        context = this;

        ivMenuInfo=findViewById(R.id.ivMenuInfo);
        baseMenu=new BaseMenu(context);
        ivMenuInfo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                baseMenu.showPopupMenu(v);
            }
        });
    }
}