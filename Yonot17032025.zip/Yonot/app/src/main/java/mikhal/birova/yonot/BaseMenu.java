package mikhal.birova.yonot;

import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.speech.tts.TextToSpeech;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.PopupMenu;
import android.widget.Toast;

public class BaseMenu {

    private final Context context;

    public BaseMenu(Context context) {
        this.context = context;
    }

    public void showPopupMenu(View anchorView) {
        PopupMenu popupMenu = new PopupMenu(context, anchorView);
        MenuInflater inflater = popupMenu.getMenuInflater();
        inflater.inflate(R.menu.main_menu, popupMenu.getMenu());

        popupMenu.setOnMenuItemClickListener(this::handleMenuItemClick);

        popupMenu.show();
    }

    public boolean handleMenuItemClick(MenuItem item) {
        int id = item.getItemId();

        if (id == R.id.action_tts_check_on) {
            LoginSignup.isTTS=1;
            Toast.makeText(context, "TextToSpeech ON", Toast.LENGTH_LONG).show();
            return true;
        }

        if (id == R.id.action_tts_check_off) {
            LoginSignup.isTTS=0;
            Toast.makeText(context, "TextToSpeech OFF", Toast.LENGTH_LONG).show();
            return true;
        }

        if (id == R.id.action_reminder) {
            Toast.makeText(context, "Reminder", Toast.LENGTH_SHORT).show();
            if (LoginSignup.isTTS==1)
                TTSManager.getInstance().speak("Reminder",
                    TextToSpeech.QUEUE_FLUSH,null,null);
            Intent intent = new Intent(context, Reminder.class);
            context.startActivity(intent);
            return true;
        }

        if (id == R.id.action_go_back) {
            if (context instanceof android.app.Activity) {
                android.app.Activity activity = (android.app.Activity) context;

                if (activity instanceof androidx.fragment.app.FragmentActivity) {
                    androidx.fragment.app.FragmentActivity fragmentActivity = (androidx.fragment.app.FragmentActivity) activity;
                    if (fragmentActivity.getSupportFragmentManager().getBackStackEntryCount() > 0) {
                        fragmentActivity.getSupportFragmentManager().popBackStack();
                    } else {
                        activity.finish();
                    }
                } else {
                    activity.finish();
                }
            }
            Toast.makeText(context, "Return to previous screen", Toast.LENGTH_SHORT).show();
            if (LoginSignup.isTTS==1)
                TTSManager.getInstance().speak("Return to previous screen",
                    TextToSpeech.QUEUE_FLUSH,null,null);
            return true;
        }


        if (id == R.id.action_exit) {
            Toast.makeText(context, "Exit from application", Toast.LENGTH_SHORT).show();
            if (LoginSignup.isTTS==1)
                TTSManager.getInstance().speak("Exit from application",
                    TextToSpeech.QUEUE_FLUSH,null,null);
            if (context instanceof android.app.Activity) {
                ((android.app.Activity) context).finishAffinity();
            }
            return true;
        }

        if (id == R.id.action_restart) {
            Toast.makeText(context, "Restart application", Toast.LENGTH_SHORT).show();
            if (LoginSignup.isTTS==1)
                TTSManager.getInstance().speak("Restart application",
                    TextToSpeech.QUEUE_FLUSH,null,null);
            Intent intent = context.getPackageManager()
                    .getLaunchIntentForPackage(context.getPackageName());
            if (intent != null) {
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                context.startActivity(intent);
            }
            return true;
        }

        if (id == R.id.action_about)  {
            Toast.makeText(context, "About me", Toast.LENGTH_SHORT).show();
            if (LoginSignup.isTTS==1)
                TTSManager.getInstance().speak("About me",
                    TextToSpeech.QUEUE_FLUSH,null,null);
            Intent intent = new Intent(context, AboutMe.class);
            context.startActivity(intent);
            return true;
        }

        if (id == R.id.action_guide)  {
            Toast.makeText(context, "Guide for application", Toast.LENGTH_SHORT).show();
            if (LoginSignup.isTTS==1)
                TTSManager.getInstance().speak("Guide for application",
                        TextToSpeech.QUEUE_FLUSH,null,null);
            Intent intent = new Intent(context, Guide.class);
            context.startActivity(intent);
            return true;
        }
        return false;
    }
}
