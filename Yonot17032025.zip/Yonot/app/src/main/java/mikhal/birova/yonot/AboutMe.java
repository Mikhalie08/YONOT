package mikhal.birova.yonot;

import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.ConnectivityManager;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

public class AboutMe extends AppCompatActivity {

    Context context;
    Button bSendSMS, bSendEmail, bCallMe;
    private NetworkReceiver networkReceiver;
    private InternetConnectionReceiver internetConnectionReceiver;
    private View ivMenuAbout;
    private BaseMenu baseMenu;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_about_me);

        ActivityCompat.requestPermissions(this,
                new String[]{android.Manifest.permission.SEND_SMS,
                        android.Manifest.permission.CALL_PHONE}, 2);

        context = this;
        bCallMe = findViewById(R.id.bCallMe);
        bSendEmail = findViewById(R.id.bSendEmail);
        bSendSMS = findViewById(R.id.bSendSMS);

        ivMenuAbout = findViewById(R.id.ivMenuAbout);
        baseMenu = new BaseMenu(this);
        ivMenuAbout.setOnClickListener(v -> baseMenu.showPopupMenu(v));

        networkReceiver = new NetworkReceiver(isConnected -> {
            bSendSMS.setEnabled(isConnected);
            bCallMe.setEnabled(isConnected);

            if (!isConnected) {
                My_Toast.showToast(context, "No network connection!", 10);
                if (LoginSignup.isTTS == 1) {
                    TTSManager.getInstance().speak("No network connection!",
                            android.speech.tts.TextToSpeech.QUEUE_FLUSH, null, null);
                }
            }
        });

        registerReceiver(networkReceiver, new IntentFilter(ConnectivityManager.CONNECTIVITY_ACTION));

        bSendSMS.setOnClickListener(v -> sendSMS());
        bCallMe.setOnClickListener(v -> makeCall());

        internetConnectionReceiver = new InternetConnectionReceiver(bSendEmail);
        registerReceiver(internetConnectionReceiver, new IntentFilter(ConnectivityManager.CONNECTIVITY_ACTION));

        bSendEmail.setOnClickListener(v -> sendEmail());
    }

    private void sendSMS() {
        String phoneNumber = "0526982256";
        String message = "Hello' it's check SMS";

        Intent smsIntent = new Intent(Intent.ACTION_VIEW);
        smsIntent.setData(Uri.parse("smsto:" + phoneNumber));
        smsIntent.putExtra("sms_body", message);
        try {
            startActivity(smsIntent);
        } catch (Exception e) {
            My_Toast.showToast(context, "Error send SMS", 10);
            if (LoginSignup.isTTS == 1) {
                TTSManager.getInstance().speak("Error send SMS",
                        android.speech.tts.TextToSpeech.QUEUE_FLUSH, null, null);
            }
        }
    }

    private void makeCall() {
        String phoneNumber = "1234567890";

        Intent callIntent = new Intent(Intent.ACTION_CALL);
        callIntent.setData(Uri.parse("tel:" + phoneNumber));
        try {
            startActivity(callIntent);
        } catch (Exception e) {
            My_Toast.showToast(context, "Error phone call", 10);
            if (LoginSignup.isTTS == 1) {
                TTSManager.getInstance().speak("Error phone call",
                        android.speech.tts.TextToSpeech.QUEUE_FLUSH, null, null);
            }
        }
    }

    private void sendEmail() {
        String[] recipients = {"?????????????"};
        String subject = "???????????";
        String message = "??????????????";

        Intent emailIntent = new Intent(Intent.ACTION_SEND);
        emailIntent.setType("message/rfc822");
        emailIntent.putExtra(Intent.EXTRA_EMAIL, recipients);
        emailIntent.putExtra(Intent.EXTRA_SUBJECT, subject);
        emailIntent.putExtra(Intent.EXTRA_TEXT, message);

        try {
            startActivity(Intent.createChooser(emailIntent, "Choice your app for e-mail"));
        } catch (Exception e) {
            My_Toast.showToast(context, "Not found app for e-mail,", 11);
            if (LoginSignup.isTTS == 1) {
                TTSManager.getInstance().speak("Not found app for e-mail",
                        android.speech.tts.TextToSpeech.QUEUE_FLUSH, null, null);
            }
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (networkReceiver != null) {
            unregisterReceiver(networkReceiver);
        }
        if (internetConnectionReceiver != null) {
            unregisterReceiver(internetConnectionReceiver);
        }
    }
}
