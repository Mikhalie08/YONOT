package mikhal.birova.yonot;

public class UserStatus {
    private String userId;
    public boolean isOnline;
    private long lastOnline;

    public UserStatus() {}

    public UserStatus(String userId, boolean isOnline, long lastOnline) {
        this.userId = userId;
        this.isOnline = isOnline;
        this.lastOnline = lastOnline;
    }

    public String getUserId() { return userId; }
    public boolean isOnline() { return isOnline; }
    public long getLastOnline() { return lastOnline; }
}