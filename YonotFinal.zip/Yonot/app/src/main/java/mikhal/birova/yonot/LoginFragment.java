package mikhal.birova.yonot;

import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageView;

public class LoginFragment extends Fragment {

    EditText etNameLF, etPasswordLF;

    ImageView ivMenuLF;
    private BaseMenu baseMenu;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view= inflater.inflate(R.layout.fragment_login, container, false);
        etNameLF=view.findViewById(R.id.etNameLF);
        etPasswordLF=view.findViewById(R.id.etPasswordLF);

        ivMenuLF=view.findViewById(R.id.ivMenuLF);
        baseMenu=new BaseMenu(getContext());
        ivMenuLF.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                baseMenu.showPopupMenu(v);
            }
        });

        return view;
    }
}