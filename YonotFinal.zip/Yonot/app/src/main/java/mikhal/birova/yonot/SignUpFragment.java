package mikhal.birova.yonot;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.os.Bundle;

import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.Fragment;

import android.speech.tts.TextToSpeech;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.Calendar;

public class SignUpFragment extends Fragment {

    EditText etNameSU, etPasswordSU, etPhoneSU, etEmailSU;
    ImageView infoName, infoPassword, infoEmail, infoPhone, ivMenuSUF;
    Button bDate;
    int cyear, cmonth,cday;
    String stName="",stPassword="",stPhone="",stEmail="",stBD="";

    BaseMenu baseMenu;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view= inflater.inflate(R.layout.fragment_sign_up, container, false);


        ivMenuSUF=view.findViewById(R.id.ivMenuSUF);
        baseMenu=new BaseMenu(getContext());
        ivMenuSUF.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                baseMenu.showPopupMenu(v);
            }
        });
        Calendar calendar = Calendar.getInstance();
        cyear = calendar.get(Calendar.YEAR);
        cmonth = calendar.get(Calendar.MONTH);
        cday = calendar.get(Calendar.DAY_OF_MONTH);

        etEmailSU=view.findViewById(R.id.etEmailAddressSU);
        etPasswordSU=view.findViewById(R.id.etPasswordSU);
        etPhoneSU=view.findViewById(R.id.etPhoneSU);
        etNameSU=view.findViewById(R.id.etNameSU);
        bDate=view.findViewById(R.id.bDate);
        bDate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                DatePickerDialog datePickerDialog = new DatePickerDialog(getActivity(),
                        new DatePickerDialog.OnDateSetListener() {
                            @Override
                            public void onDateSet(DatePicker datePicker, int year, int month, int day) {
                                stBD = day + "." + (month+1) + "." + year;
                                goNext();
                            }
                        }, cyear, cmonth, cday);
                //datePickerDialog.getDatePicker().setMinDate(System.currentTimeMillis());
                datePickerDialog.show();
                //goNext();
            }
        });
        infoName=view.findViewById(R.id.infoName);
        infoPassword=view.findViewById(R.id.infoPassword);
        infoEmail=view.findViewById(R.id.infoEmail);
        infoPhone=view.findViewById(R.id.infoPhone);
        infoName.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                viewInfo(1);
            }
        });
        return view;
    }

    private void goNext() {
        stName=etNameSU.getText().toString();
        stPassword=etPasswordSU.getText().toString();
        stPhone=etPhoneSU.getText().toString();
        stEmail=etEmailSU.getText().toString();
        User user=new User(stName,stPassword,stEmail,stPhone,stBD);
        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        LayoutInflater inflater = LayoutInflater.from(getActivity());
        View dialogView = inflater.inflate(R.layout.continue_signup_dialog, null);
        builder.setView(dialogView);
        TextView tvUserData = dialogView.findViewById(R.id.tvSUDC);
        Button bNo = dialogView.findViewById(R.id.bNo);
        Button bYes = dialogView.findViewById(R.id.bYes);
        String userData = "Name: " + user.getuName() + "\n" +
                "Password: " + user.getuPass() + "\n" +
                "Email: " + user.getuMail() + "\n" +
                "Phone: " + user.getuPhone() + "\n" +
                "Birthday: " + user.getuBD();
        tvUserData.setText(userData);
        if (LoginSignup.isTTS==1)  {
            TTSManager.getInstance().speak(userData,
                    TextToSpeech.QUEUE_FLUSH, null, null);
        }
        AlertDialog alertDialog = builder.create();

        bNo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                alertDialog.dismiss();
            }
        });

        bYes.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                LoginSignup activity = (LoginSignup) getActivity();
                if (activity != null) {
                    //activity.setLoginData(user);
                    Intent intent = new Intent(requireContext(), Home.class);
                    intent.putExtra("user",user);
                    requireContext().startActivity(intent);
                }
                alertDialog.dismiss();
            }
        });
        alertDialog.show();
    }

    private void viewInfo(int i) {
        String[] about={"name","password","E-mail","phone"};
        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        LayoutInflater inflater = LayoutInflater.from(getActivity());
        View dialogView = inflater.inflate(R.layout.info_dialog, null);
        builder.setView(dialogView);
        TextView tvInfoAbout = dialogView.findViewById(R.id.tvInfoAbout);
        TextView tvAllInfo = dialogView.findViewById(R.id.tvAllInfo);
        Button bCloseInfo = dialogView.findViewById(R.id.bCloseInfo);
        tvInfoAbout.setText("It's information about "+about[i]);
        if (LoginSignup.isTTS==1)  {
            TTSManager.getInstance().speak(tvInfoAbout.getText().toString(),
                    TextToSpeech.QUEUE_FLUSH, null, null);
        }
        tvAllInfo.setText(getResources().getString(R.string.about_name));
        if (LoginSignup.isTTS==1)  {
            TTSManager.getInstance().speak(tvAllInfo.getText().toString(),
                    TextToSpeech.QUEUE_FLUSH, null, null);
        }
        AlertDialog alertDialog = builder.create();
        bCloseInfo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                alertDialog.dismiss();
            }
        });
        alertDialog.show();
    }


}