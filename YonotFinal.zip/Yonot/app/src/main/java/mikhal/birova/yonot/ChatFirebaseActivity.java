package mikhal.birova.yonot;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.FirebaseApp;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.*;
import java.util.ArrayList;
import java.util.List;

public class ChatFirebaseActivity extends AppCompatActivity {
    TextView tvSubject;
    private EditText messageEditText, emailEditText, passwordEditText;
    private Button sendButton, registerButton, loginButton;
    private RecyclerView recyclerView, onlineUsersRecyclerView;
    private MessageAdapter messageAdapter;
    private OnlineUsersAdapter onlineUsersAdapter;
    private List<Message> messageList;
    private List<UserStatus> onlineUsersList;
    private DatabaseReference messagesRef, presenceRef;
    private FirebaseAuth auth;
    private FirebaseUser user;
    private Intent takeit;
    String subject="";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chat_firebase);

        takeit=getIntent();
        subject=takeit.getStringExtra("what");


        FirebaseApp.initializeApp(this);
        auth = FirebaseAuth.getInstance();
        user = auth.getCurrentUser();

        emailEditText = findViewById(R.id.emailEditText);
        passwordEditText = findViewById(R.id.passwordEditText);
        registerButton = findViewById(R.id.registerButton);
        loginButton = findViewById(R.id.loginButton);
        messageEditText = findViewById(R.id.messageEditText);
        sendButton = findViewById(R.id.sendButton);
        recyclerView = findViewById(R.id.recyclerView);
        onlineUsersRecyclerView = findViewById(R.id.onlineUsersRecyclerView);
        tvSubject=findViewById(R.id.tvSubject);
        tvSubject.setText("Subject for conversation: "+subject+"");

        messageList = new ArrayList<>();
        messageAdapter = new MessageAdapter(messageList);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(messageAdapter);

        onlineUsersList = new ArrayList<>();
        onlineUsersAdapter = new OnlineUsersAdapter();
        onlineUsersRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        onlineUsersRecyclerView.setAdapter(onlineUsersAdapter);

        messagesRef = FirebaseDatabase.getInstance().getReference("messages");
        presenceRef = FirebaseDatabase.getInstance().getReference("presence");

        registerButton.setOnClickListener(v -> registerUser());
        loginButton.setOnClickListener(v -> loginUser());
        sendButton.setOnClickListener(v -> sendMessage());

        updateUI(user);
        if (user != null) {
            setupPresence();
            loadMessages();
            loadOnlineUsers();
        }
    }

    private void registerUser() {
        String email = emailEditText.getText().toString().trim();
        String password = passwordEditText.getText().toString().trim();

        if (TextUtils.isEmpty(email) || TextUtils.isEmpty(password)) {
            Toast.makeText(this, "Please enter email and password", Toast.LENGTH_SHORT).show();
            return;
        }

        auth.createUserWithEmailAndPassword(email, password)
                .addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful()) {
                            user = auth.getCurrentUser();
                            setupPresence();
                            loadMessages();
                            loadOnlineUsers();
                            updateUI(user);
                            Toast.makeText(ChatFirebaseActivity.this, "Registration successful",
                                    Toast.LENGTH_SHORT).show();
                        } else {
                            Toast.makeText(ChatFirebaseActivity.this, "Registration failed: " +
                                    task.getException().getMessage(), Toast.LENGTH_SHORT).show();
                        }
                    }
                });
    }

    private void loginUser() {
        String email = emailEditText.getText().toString().trim();
        String password = passwordEditText.getText().toString().trim();

        if (TextUtils.isEmpty(email) || TextUtils.isEmpty(password)) {
            Toast.makeText(this, "Please enter email and password", Toast.LENGTH_SHORT).show();
            return;
        }

        auth.signInWithEmailAndPassword(email, password)
                .addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful()) {
                            user = auth.getCurrentUser();
                            setupPresence();
                            loadMessages();
                            loadOnlineUsers();
                            updateUI(user);
                            Toast.makeText(ChatFirebaseActivity.this, "Login successful",
                                    Toast.LENGTH_SHORT).show();
                        } else {
                            Toast.makeText(ChatFirebaseActivity.this, "Login failed: " +
                                    task.getException().getMessage(), Toast.LENGTH_SHORT).show();
                        }
                    }
                });
    }

    private void setupPresence() {
        if (user == null) return;

        String userId = user.getUid();
        DatabaseReference userPresenceRef = presenceRef.child(userId);

        UserStatus onlineStatus = new UserStatus(userId, true, System.currentTimeMillis());
        userPresenceRef.setValue(onlineStatus);

        userPresenceRef.onDisconnect().setValue(
                new UserStatus(userId, false, System.currentTimeMillis()));
    }

    private void loadOnlineUsers() {
        presenceRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                List<UserStatus> updatedUsers = new ArrayList<>();
                for (DataSnapshot userSnapshot : snapshot.getChildren()) {
                    UserStatus status = userSnapshot.getValue(UserStatus.class);
                    if (status != null) {
                        long timeDiff = System.currentTimeMillis() - status.getLastOnline();
                        status.isOnline = status.isOnline() && timeDiff < 300000; // 5 минут
                        updatedUsers.add(status);
                    }
                }
                onlineUsersList = updatedUsers;
                onlineUsersAdapter.updateUsers(onlineUsersList);
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(ChatFirebaseActivity.this, "Error loading users", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void sendMessage() {
        String text = messageEditText.getText().toString().trim();
        if (!TextUtils.isEmpty(text) && user != null) {
            String userId = user.getUid();
            Message message = new Message(userId, text);
            messagesRef.push().setValue(message)
                    .addOnCompleteListener(task -> {
                        if (task.isSuccessful()) {
                            messageEditText.setText("");
                        } else {
                            Toast.makeText(this, "Error sending message", Toast.LENGTH_SHORT).show();
                        }
                    });
        }
    }

    private void loadMessages() {
        if (user == null) return;

        messagesRef.addChildEventListener(new ChildEventListener() {
            @Override
            public void onChildAdded(@NonNull DataSnapshot snapshot, String previousChildName) {
                Message message = snapshot.getValue(Message.class);
                if (message != null) {
                    messageList.add(message);
                    messageAdapter.notifyItemInserted(messageList.size() - 1);
                    recyclerView.scrollToPosition(messageList.size() - 1);
                }
            }

            @Override
            public void onChildChanged(@NonNull DataSnapshot snapshot, String previousChildName) {}
            @Override
            public void onChildRemoved(@NonNull DataSnapshot snapshot) {}
            @Override
            public void onChildMoved(@NonNull DataSnapshot snapshot, String previousChildName) {}
            @Override
            public void onCancelled(@NonNull DatabaseError error) {}
        });
    }

    private void updateUI(FirebaseUser user) {
        this.user = user;
        if (user != null) {
            emailEditText.setVisibility(View.GONE);
            passwordEditText.setVisibility(View.GONE);
            registerButton.setVisibility(View.GONE);
            loginButton.setVisibility(View.GONE);
            messageEditText.setVisibility(View.VISIBLE);
            sendButton.setVisibility(View.VISIBLE);
            recyclerView.setVisibility(View.VISIBLE);
            onlineUsersRecyclerView.setVisibility(View.VISIBLE);
            findViewById(R.id.onlineUsersTitle).setVisibility(View.VISIBLE);
        } else {
            emailEditText.setVisibility(View.VISIBLE);
            passwordEditText.setVisibility(View.VISIBLE);
            registerButton.setVisibility(View.VISIBLE);
            loginButton.setVisibility(View.VISIBLE);
            messageEditText.setVisibility(View.GONE);
            sendButton.setVisibility(View.GONE);
            recyclerView.setVisibility(View.GONE);
            onlineUsersRecyclerView.setVisibility(View.GONE);
            findViewById(R.id.onlineUsersTitle).setVisibility(View.GONE);
        }
    }
}