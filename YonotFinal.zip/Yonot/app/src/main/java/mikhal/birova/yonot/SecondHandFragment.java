package mikhal.birova.yonot;

import android.content.Intent;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;


public class SecondHandFragment extends Fragment {

    private ImageView ivMenuSHF;
    private BaseMenu baseMenu;
    private Button bP,bE,bS,bP1,bP2,bP3,bE1,bE2,bE3,bS1,bS2;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view= inflater.inflate(R.layout.fragment_second_hand, container, false);

        bP=view.findViewById(R.id.bPigeon);
        bE=view.findViewById(R.id.bEquip);
        bS=view.findViewById(R.id.bService);
        bP1=view.findViewById(R.id.bP1);
        bP2=view.findViewById(R.id.bP2);
        bP3=view.findViewById(R.id.bP3);
        bE1=view.findViewById(R.id.bE1);
        bE2=view.findViewById(R.id.bE2);
        bE3=view.findViewById(R.id.bE3);
        bS1=view.findViewById(R.id.bS1);
        bS2=view.findViewById(R.id.bS2);


        bP.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                bE1.setVisibility(View.GONE);
                bE2.setVisibility(View.GONE);
                bE3.setVisibility(View.GONE);
                bS1.setVisibility(View.GONE);
                bS2.setVisibility(View.GONE);
            }
        });

        bE.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                bP1.setVisibility(View.GONE);
                bP2.setVisibility(View.GONE);
                bP3.setVisibility(View.GONE);
                bS1.setVisibility(View.GONE);
                bS2.setVisibility(View.GONE);
            }
        });

        bS.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                bP1.setVisibility(View.GONE);
                bP2.setVisibility(View.GONE);
                bP3.setVisibility(View.GONE);
                bE1.setVisibility(View.GONE);
                bE2.setVisibility(View.GONE);
                bE3.setVisibility(View.GONE);
            }
        });

        bP1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent go=new Intent(getContext(), WantToBuy.class);
                go.putExtra("what",bP1.getText());
                startActivity(go);
            }
        });

        ivMenuSHF=view.findViewById(R.id.ivMenuSHF);
        baseMenu=new BaseMenu(getContext());
        ivMenuSHF.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                baseMenu.showPopupMenu(v);
            }
        });

        return view;
    }
}