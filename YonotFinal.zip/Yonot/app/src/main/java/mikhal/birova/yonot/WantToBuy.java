package mikhal.birova.yonot;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class WantToBuy extends AppCompatActivity {

    Context context;
    private Button bChat;
    Intent takeit;
    String what="";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_want_to_buy);

        context=this;
        takeit=getIntent();
        what=takeit.getStringExtra("what");

        bChat=findViewById(R.id.bChat);
        bChat.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent go=new Intent(context, ChatFirebaseActivity.class);
                go.putExtra("what",what);
                startActivity(go);
            }
        });
    }
}